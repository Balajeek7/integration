package com.sfdc.model;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sfdc.exceptions.CSVDataException;
import com.sfdc.exceptions.FieldMappingException;
import com.sfdc.exceptions.XMLParsingException;
import com.sfdc.utils.CSVUtils;
import com.sfdc.utils.XMLParser;

public class DataFetcher {
	public JSONArray mapBean(String xmlFile, String csvFile) throws FieldMappingException, CSVDataException, XMLParsingException{
		JSONArray jsonArray = null;
		try {
			jsonArray = new JSONArray();
			XMLParser parser = new XMLParser(xmlFile);
			CSVUtils csvParser = new CSVUtils();
			List fields = parser.parseByDomain("Leads","Field");
			List values = csvParser.parseCSV(csvFile);
			String[][] data = new String[fields.size()][values.size()];
			Integer[] valuesCount = new Integer[values.size()];
			List<String> valueList = null;
			List csvValues = new ArrayList();
			for (int x = 0; x < values.size(); x++) {
				valueList = ((List<String>) values.get(x));
				valuesCount[x] = valueList.get(0).split(",").length;
				csvValues.add(Arrays.asList(valueList.get(0).split(",")));
			}
			for (int i = 0; i < values.size(); i++) {
				JSONObject json = new JSONObject();
				for (int j = 0; j < valuesCount[i]; j++) {
					json.put((String) fields.get(j),((List) csvValues.get(i)).get(j));
				}
				jsonArray.put(json);
			}
		} catch(FileNotFoundException fne){
			fne.printStackTrace();
		} catch(JSONException je){
			je.printStackTrace();
		}
		return jsonArray;
	}
	
}
