package com.sfdc.rest;

import com.sfdc.exceptions.SFDCConnectionException;
import com.sfdc.exceptions.SFDCException;
import com.sfdc.exceptions.XMLParsingException;
import com.sfdc.utils.XMLParser;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/**
 * @author Mellisa Sheppard
 * Created on 26 july 2016
 * This class is used to integrate salesforce
 *
 */
public class SFDCConnector
{
  private final String GRANTSERVICE = "/services/oauth2/token?grant_type=password";
  private final String LOGINURL = "https://login.salesforce.com";
  private final String REST_ENDPOINT = "/services/data";
  private final String API_VERSION = "/v32.0";
  private String baseUri;
  private Header oauthHeader;
  private String configFile;
  /**
 * @author Mellisa sheppard
 * created on 26 july 2016
 * This main method is used to connect salesforce using credentials configured in sfdcConfig.xml
 * 
 * @param args
 * @throws SFDCException
 */
  
  public SFDCConnector(String configFile){
	this.configFile = configFile;  
  }
  
public Map<String,Object> connectSFDC()
    throws SFDCConnectionException, XMLParsingException
  {
	Map<String,Object> connectionDetails = null;
    HttpClient httpclient = HttpClientBuilder.create().build();
    
    XMLParser xml = new XMLParser(configFile);
    
    String loginURL = LOGINURL+GRANTSERVICE + "&client_id="+
      xml.parseByElement("ConsumerKey") + "&client_secret=" + 
      xml.parseByElement("ConsumerSecret") + "&username=" + 
      xml.parseByElement("Username") + "&password=" + xml.parseByElement("Password") + 
      xml.parseByElement("SecurityToken");
    
    HttpPost httpPost = new HttpPost(loginURL);
    HttpResponse response = null;
    try
    {
      response = httpclient.execute(httpPost);
    }
    catch (ClientProtocolException cpException)
    {
      cpException.printStackTrace();
    }
    catch (IOException ioException)
    {
      ioException.printStackTrace();
    }
    int statusCode = response.getStatusLine().getStatusCode();
    if (statusCode != 200)
    {
      System.out.println("Error authenticating to Force.com: " + 
        statusCode);
    } else{
    	connectionDetails = new HashMap<String,Object>();
    	String getResult = null;
    	try
    	{
    		getResult = EntityUtils.toString(response.getEntity());
    	}	
    	catch (IOException ioException)
    	{
    		ioException.printStackTrace();
    	}
    	JSONObject jsonObject = null;
    	String loginAccessToken = null;
    	String loginInstanceUrl = null;
    	try
    	{
    		jsonObject = (JSONObject)new JSONTokener(getResult).nextValue();
    		loginAccessToken = jsonObject.getString("access_token");
    		loginInstanceUrl = jsonObject.getString("instance_url");
    	}
    	catch (JSONException jsonException)
    	{
    		jsonException.printStackTrace();
    	}
    	baseUri = loginInstanceUrl + REST_ENDPOINT + API_VERSION;
    	oauthHeader = new BasicHeader("Authorization", "OAuth "+ loginAccessToken);
    	connectionDetails.put("baseUri",baseUri);
    	connectionDetails.put("oauthHeader",oauthHeader);
    	System.out.println(response.getStatusLine());
    	System.out.println("successfully connected to salesforce");
    	System.out.println("  instance URL: " + loginInstanceUrl);
    	System.out.println("  access token/session ID: " + loginAccessToken);
    }
    return connectionDetails;
  }
}
