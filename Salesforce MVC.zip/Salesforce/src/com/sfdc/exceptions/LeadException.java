package com.sfdc.exceptions;

public class LeadException extends SFDCException {
	public LeadException(String exception){
		super(exception);
	}
}
