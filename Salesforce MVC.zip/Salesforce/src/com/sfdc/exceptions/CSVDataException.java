package com.sfdc.exceptions;

public class CSVDataException extends SFDCException{

	public CSVDataException(String exception){
		super(exception);
	}
}
