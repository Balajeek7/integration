package com.sfdc.exceptions;

public class SFDCConnectionException extends SFDCException {

	public SFDCConnectionException(String exception) {
		super(exception);
	}

}
