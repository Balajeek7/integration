package com.sfdc.exceptions;

public class FieldMappingException extends SFDCException{

	public FieldMappingException(String exception){
		super(exception);
	}
}
