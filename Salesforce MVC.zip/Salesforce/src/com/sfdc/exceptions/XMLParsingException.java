package com.sfdc.exceptions;

public class XMLParsingException extends SFDCException {

	public XMLParsingException(String exception) {
		super(exception);
	}

}
