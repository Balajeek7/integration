package com.sfdc.exceptions;

public class SFDCException extends Exception{
	public SFDCException(String exception){
		super(exception);
	}
}
