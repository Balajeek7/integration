package com.sfdc.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sfdc.exceptions.SFDCException;
import com.sfdc.exceptions.XMLParsingException;

public class XMLParser {
	private String fileName;

	public XMLParser(String fileName) {
		this.fileName = fileName;
	}
	public List parseByList(String elementName)throws XMLParsingException{
		List values = new ArrayList();
		try {
			File xml = new File(fileName);
			if (xml.exists()) {
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(xml);
				Element docEle = doc.getDocumentElement();
				doc.getDocumentElement().normalize();
				NodeList nodes = docEle.getElementsByTagName(elementName);
				for (int i = 0; i < nodes.getLength(); i++) {
					Node node = nodes.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element element = (Element) node;
						values.add(nodes.item(i).getTextContent());
					}
				}
			} else {
				throw new SFDCException("File not found with this file name: "
						+ fileName);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return values;
	}
	public String parseByElement(String elementName)throws XMLParsingException {
		String elementValue = null;
		try {
			File credentials = new File(fileName);
			if (credentials.exists()) {
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(credentials);
				doc.getDocumentElement().normalize();
				Element docEle = doc.getDocumentElement();
				NodeList nodes = docEle.getElementsByTagName(elementName);
				for (int i = 0; i < nodes.getLength(); i++) {
					Node node = nodes.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element element = (Element) node;
						elementValue = element.getTextContent();
					}
				}
			} else {
				throw new XMLParsingException(
						"No file found in the name of "+fileName);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return elementValue;
	}
	public List parseByDomain(String domainName, String elementName)
	  {
	    List elementValue = null;
	    try
	    {
	    elementValue = new ArrayList();
	      File xml = new File(this.fileName);
	      DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	      Document doc = dBuilder.parse(xml);
	      doc.getDocumentElement().normalize();
	      NodeList nodes = doc.getElementsByTagName(domainName);
	      for (int i = 0; i < nodes.getLength(); i++)
	      {
	        Node node = nodes.item(i);
	        if (node.getNodeType() == 1)
	        {
	          Element element = (Element)node;
	          NodeList nodeList = element.getElementsByTagName(elementName);
	          for(int j=0;j<nodeList.getLength();j++){
	        	  elementValue.add(nodeList.item(j).getTextContent());
	          }
	          //elementValue.add(getValue(elementName, element));
	        }
	      }
	    }
	    catch (Exception ex)
	    {
	      ex.printStackTrace();
	    }
	    return elementValue;
	  }

	private String getValue(String tag, Element element)throws XMLParsingException {
		NodeList nodes = element.getElementsByTagName(tag);//.item(0).getChildNodes()
		Node node = (Node) nodes.item(0);
		return node.getNodeValue();
	}
}
