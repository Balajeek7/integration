package com.sfdc.controller;

import java.util.Map;

import org.apache.http.Header;
import com.sfdc.exceptions.LeadException;
import com.sfdc.exceptions.SFDCConnectionException;
import com.sfdc.exceptions.SFDCException;
import com.sfdc.rest.SFDCConnector;

public class SFDCController {
	private static String CONFIGFILE = "sfdc-config.xml";
	public static void main(String args[]) throws SFDCException, LeadException {
		Header oauthHeader = null;
		String baseUri = null;
		LeadController leadObj = null;
		SFDCConnector connection = null;
		Map<String,Object> connectionDetails = null;
		try{
			connection = new SFDCConnector(CONFIGFILE);
			connectionDetails = connection.connectSFDC();
			if(connectionDetails != null){
				baseUri = (String) connectionDetails.get("baseUri");
				oauthHeader = (Header) connectionDetails.get("oauthHeader");
				for(int i=0;i<args.length;i++){
					if(args[i].equalsIgnoreCase("lead")) {	
						leadObj = new LeadController(baseUri, oauthHeader);
						if (args[i+1].equalsIgnoreCase("insert")) {
							leadObj.createLeads();
						} else if (args[i+1].equalsIgnoreCase("update")) {
							if(args.length==3)
								leadObj.updateLeads(args[i+2]);
							else
								System.out.println("Please enter Lead Id to update");
						} else if (args[i+1].equalsIgnoreCase("delete")) {
							if(args.length==3)
								leadObj.deleteLeads(args[i+2]);
							else
								System.out.println("Please enter Lead Id to delete");
						} else if (args[i+1].equalsIgnoreCase("query")) {
							leadObj.queryLeads();
						} else {
							throw new LeadException("Please enter any of these operations(insert,update,query,delete)");
						}
					} break;
				}
			}else{
				throw new SFDCConnectionException("Connection Error");
			}
		}catch(ArrayIndexOutOfBoundsException exception){
			System.out.println("please enter parameters to perform tasks");
		}
		catch(SFDCException exception){
			exception.printStackTrace();
		}
	}
}