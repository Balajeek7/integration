How to run the JAR file?

----> Extract the sfdc.zip file, there you can find sfdc.jar and sfdcConfig.xml. Before running the JAR file, you should provide credentials such as username, password, security token, consumer key and consumer secret in sfdcConfig.xml

----> After providing credentials kindly save the sfdcConfig.xml file and close it. Now, Open command prompt and navigate to the folder in which sfdc.jar resides. And type the command �java �jar sfdc.jar� and press enter. 

For screenshots, please refer documentation.